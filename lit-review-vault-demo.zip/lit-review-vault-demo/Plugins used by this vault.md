[Admonition](https://github.com/valentine195/obsidian-admonition)
[Dataview](https://github.com/blacksmithgu/obsidian-dataview)
[Pandoc Reference List](https://github.com/mgmeyers/obsidian-pandoc-reference-list)
[Pandoc](https://github.com/OliverBalfour/obsidian-pandoc)
[Zotero Integration](https://github.com/mgmeyers/obsidian-zotero-integration)
### nb
One could have '[smart connections](https://github.com/brianpetro/obsidian-smart-connections)' installed in this vault, which uses a local LLM to create vector embeddings of all notes. Once created, you can ask questions of the vault insofar as the plugin will turn your question into an embedding, then retrieve all of the embeddings that are 'closest' to your question. Such experiments are in the 'smart-chats' folder. Don't bother with this unless you really want to get into the nitty gritty of locally hosted LLMs and all the madness that will ensue.
