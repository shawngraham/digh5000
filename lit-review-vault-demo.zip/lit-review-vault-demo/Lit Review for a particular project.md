
```dataview
TABLE   
title as Title,   
itemType as Item,   
status as Status,   
dateread as Read,   
contribution as Contribution  
FROM "literature notes"
WHERE contains(tags, "gravity")  
SORT status DESC, read DESC
```

Use the tag 'DataLitReview' on anything that you want to include for the actual review for a given project, or whatever tag is appropriate to that project. Put the mouse in the dataview query box and change this line:

```
WHERE contains(tags, "gravity")  
```

to whatever tag describes the particular project whose readings you want to look at here.