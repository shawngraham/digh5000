```dataview
TABLE
title as Title, 
FirstAuthor as "First Author", 
Year as Year,
itemType as Item, 
Citekey as Citekey, 
Contribution as Contribution
FROM "literature notes"
```


This should list everything.
