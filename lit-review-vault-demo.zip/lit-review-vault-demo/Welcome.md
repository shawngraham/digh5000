This is your new *literature review vault*. Following this [blog post](https://medium.com/@alexandraphelan/an-updated-academic-workflow-zotero-obsidian-cffef080addd) and this [one](https://medium.com/@alexandraphelan/literature-reviews-using-zotero-obsidian-66eba1565d78). Take the time to read both posts. **The posts will tell you how to configure the plugins correctly,** including how to export your zotero library .bib file such that it updates whenever you add/modify things in your Zotero and those updates are available over here.

When you read an article in Zotero using its built in pdf reader, use colours, eg:

blue: thesis/contention of the paper
yellow: something interesting
green: something to pursue further

**nb** Zotero needs the better bibtext plugin installed and working.

## quick hints 

+ Hit cmd+p to open the command panel. Type 'zotero' and select create a literature note. When the zotero selector opens, select the piece whose notes/annotations you want to import.  This will make a new literature note, and will sort out the annotations according to colour. Click on the note to add further metadata or a summary etc. Make sure to add tags that indicate what project of yours the article might be useful for. In the 'summary' notes, you can modify the dataview query to show a table of just the notes for a particular project.

+ If in a note you start typing `[[` and follow that with a ``@`` you can quickly insert a link to your literature notes, eg [[@gormanCultureMoonBodies2016]]

+ If you want that link to appear as an in-text citation (say you're writing an article draft,) use `[` rather than the double square brackets (move your cursor into the brackets below to see):

> blah blah [@labradorOntologiesFutureInterfaces2012] is blah blah [@leidwangerManifestoStudyAncient2014] blah blah [@vicknairComparisonGraphDatabase2010a] and more blah [@walsh2020a] blah blah blah [@graham2012bricks] asdflkj 

Once you resume typing along the line Obsidian will turn the link into an in-text citation. Then, when you click on the right side bar and the references button, you've got the full bibliography right there for copy-pasting, eg:

Graham, S. 2012 Bricks and brick making, Roman. In:. _The encyclopedia of ancient history_. Wiley-Black DOI: 10.1002/9781444338386.wbeah10016. p.

Labrador, AM. 2012 Ontologies of the Future and Interfaces for All: Archaeological Databases for the Twenty-First Century. _Archaeologies_ 8(3): 236–249. DOI: [https://doi.org/10.1007/s11759-012-9203-2](https://doi.org/10.1007/s11759-012-9203-2).

Leidwanger, J, Knappett, C, Arnaud, P, Arthur, P, Blake, E, Broodbank, C, Brughmans, T, Evans, T, Graham, S and Greene, ES. 2014 A manifesto for the study of ancient Mediterranean maritime networks. _Antiquity_ 342(88): 1–5.

Vicknair, C, Macias, M, Zhao, Z, Nan, X, Chen, Y and Wilkins, D. 2010 A comparison of a graph database and a relational database: a data provenance perspective. In:. _Proceedings of the 48th Annual Southeast Regional Conference_. 15 April 2010. Oxford Mississippi: ACM. pp. 1–6. DOI: [https://doi.org/10.1145/1900008.1900067](https://doi.org/10.1145/1900008.1900067).

Walsh, M. 2020 _Introduction to cultural analytics & python_ ,. DOI: [https://doi.org/10.5281/zenodo.4411250.](https://doi.org/10.5281/zenodo.4411250.)

...obviously, I'm missing a bit of metadata in my zotero library...










