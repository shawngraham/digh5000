---
category: literaturenote
tags:
  - database
  - theory
citekey: vicknairComparisonGraphDatabase2010a
status: read
dateread:
---

> [!Cite]
> Vicknair, C, Macias, M, Zhao, Z, Nan, X, Chen, Y and Wilkins, D. 2010 A comparison of a graph database and a relational database: a data provenance perspective. In:. _Proceedings of the 48th Annual Southeast Regional Conference_. 15 April 2010. Oxford Mississippi: ACM. pp. 1–6. DOI: [https://doi.org/10.1145/1900008.1900067](https://doi.org/10.1145/1900008.1900067).

>[!Synth]
>**Contribution**::when a graph database might be appropriate 
>
>**Related**:: 
>

>[!md]
> **FirstAuthor**:: Vicknair, Chad  
> **Author**:: Macias, Michael  
> **Author**:: Zhao, Zhendong  
> **Author**:: Nan, Xiaofei  
> **Author**:: Chen, Yixin  
> **Author**:: Wilkins, Dawn  
~    
> **Title**:: A comparison of a graph database and a relational database: a data provenance perspective  
> **Year**:: 2010   
> **Citekey**:: vicknairComparisonGraphDatabase2010a  
> **itemType**:: conferencePaper  
> **Publisher**:: ACM  
> **Location**:: Oxford Mississippi   
> **Pages**:: 1-6  
> **DOI**:: 10.1145/1900008.1900067  
> **ISBN**:: 978-1-4503-0064-3    

> [!LINK] 
>
>  [Vicknair et al. - 2010 - A comparison of a graph database and a relational .pdf](file:///Users/shawngraham/Zotero/storage/V4JNURPS/Vicknair%20et%20al.%20-%202010%20-%20A%20comparison%20of%20a%20graph%20database%20and%20a%20relational%20.pdf).

> [!Abstract]
>
> Relational databases have been around for many decades and are the database technology of choice for most traditional data-intensive storage and retrieval applications. Retrievals are usually accomplished using SQL, a declarative query language. Relational database systems are generally eﬃcient unless the data contains many relationships requiring joins of large tables. Recently there has been much interest in data stores that do not use SQL exclusively, the socalled NoSQL movement. Examples are Google’s BigTable and Facebook’s Cassandra. This paper reports on a comparison of one such NoSQL graph database called Neo4j with a common relational database system, MySQL, for use as the underlying technology in the development of a software system to record and query data provenance information.
>.
> 
# Notes

>.


# Annotations%% begin annotations %%



### Imported: 2024-02-14 4:06 pm



<mark style="background-color: #5fb236">Quote</mark>
> A directed acyclic graph (DAG) is a common data structure to store data provenance infor- mation relationships. The goal of this study was to deter- mine whether a traditional relational database system like MySQL, or a graph database, such as Neo4j, would be more effective as the underlying technology for the development of a data provenance system.

<mark style="background-color: #5fb236">Quote</mark>
> Graphs truly are one of the most useful structures for modeling objects and interactions

<mark style="background-color: #5fb236">Quote</mark>
> Provenance about a data item includes details about processes used to create the item and provenance about input data used to create the item.  Complete provenance of an item might include source data recorded by hand, by sensors, etc. and all of the subsequent processes and file versions that came to make up the item.

<mark style="background-color: #5fb236">Quote</mark>
> While storing a graph in a relational database is simple, querying it, particularly traversing it, can be time-inefficient due to the number of potential joins.  As such, it is appropriate to consider non-traditional data storage models

<mark style="background-color: #5fb236">Quote</mark>
> Atomicity, consistency, isolation, and durability (ACID) are a set of governing principles of the relational model.

<mark style="background-color: #5fb236">Quote</mark>
> As the typical database administrator attempts to ques- tion whether to move from the relational model to a NoSQL model, the NoSQL community presents him or her with potential flags that the data might be more suitable for a NoSQL system [5].  1. Having tables with lots of columns, each of which is only used by a few rows.  2. Having attribute tables.  3. Having lots of many-to-many relationships.  4. Having tree-like characteristics.  5. Requiring frequent schema changes.  Data provenance meets several of these criteria,


%% end annotations %%

%% Import Date: 2024-02-14T16:07:02.606-05:00 %%
