---
Title: "Memory Institutions Meet AI: Lessons from Critical Technology Discourse"
Authors: Jordan Famularo, Remi Denton
Publication: "International Journal for Digital Art History"
Date: 2023-01-01
citekey: famularoMemoryInstitutionsMeet2023
tags: #accessibility
---

> [!Cite]
> Famularo, J and Denton, R. 2023 Memory Institutions Meet AI: Lessons from Critical Technology Discourse. _International Journal for Digital Art History_ (9): 3.02-3.27. DOI: [https://doi.org/10.11588/dah.2023.9.91468](https://doi.org/10.11588/dah.2023.9.91468).

>[!Synth]
>**Contribution**:: 
>
>**Related**:: 
>

>[!md]
> **FirstAuthor**:: Famularo, Jordan  
> **Author**:: Denton, Remi  
~    
> **Title**:: Memory Institutions Meet AI: Lessons from Critical Technology Discourse  
> **Year**:: 2023   
> **Citekey**:: famularoMemoryInstitutionsMeet2023  
> **itemType**:: journalArticle  
> **Journal**:: *International Journal for Digital Art History*  
> **Issue**:: 9   
> **Pages**:: 3.02-3.27  
> **DOI**:: 10.11588/dah.2023.9.91468    

> [!LINK] 
>
>  [Famularo and Denton - 2023 - Memory Institutions Meet AI Lessons from Critical Technology Discourse.pdf](file:///Users/shawngraham/Zotero/storage/37EYJ4NA/Famularo%20and%20Denton%20-%202023%20-%20Memory%20Institutions%20Meet%20AI%20Lessons%20from%20Critical%20Technology%20Discourse.pdf).

> [!Abstract]
>
> Galleries, libraries, archives, and museums (GLAMs) across the globe are building new datasets to render their collections open, machine-readable, and internet-accessible. The new generation of GLAM datasets have wide reach, offering to turn institutions inside-out so that remote audiences can view, download, share, and remix digital assets. GLAM institutions have treated the associated turn to open data as inherently positive—able to promote cultural understanding and appreciation in ways that promise scale, accessibility, and customization. However, some critics suggest that upsides of technology for GLAM datasets need to be balanced with risks that can arise from their design, development, and integration into artificial intelligence (AI) technologies. In this work we ask: how should GLAMs account for the emergence of AI-driven experiences built upon GLAM datasets? We seek to answer this question by flagging key ethics and governance issues in tandem with supplying some guardrails for navigating them. We examine GLAM datasets from a sociotechnical perspective. Drawing on our experiences as researchers spanning multiple areas (computer science, computer vision, AI ethics, art history, and cybersecurity) and working in different sectors (industry and academia), we identify salient concerns and remediations from critical technology discourse on dataset development for AI systems.
>.
> 
> ### Note
>.


>[!Annotation|#2ea8e5]+ 
>*" how should GLAMs account for the emergence of AI-driven experiences built upon GLAM datasets? We seek to answer this question by flagging key ethics and governance issues in tandem with supplying some guardrails for navigating them. "*([2](zotero://open-pdf/library/items/37EYJ4NA?page=2&annotation=6EWPB4T3))

>[!Annotation|#2ea8e5]+ 
>*" GLAM datasets as sociotechnical systems "*([2](zotero://open-pdf/library/items/37EYJ4NA?page=2&annotation=T2QCKK3F))

>[!Annotation|#2ea8e5]+ 
>*" The making and stewarding of GLAM datasets thus becomes the central concept shaping how we organize our exposition and recommendations "*([3](zotero://open-pdf/library/items/37EYJ4NA?page=3&annotation=H4MIR435))

>[!Annotation|#ffd400]+ 
>*" to a 2022 Open GLAM Survey, more than 1,400 GLAM institutions worldwide have released digital collections on open access terms.12 These include some of the 3,700+ institutions that participate in the European Union’s Europeana,13 the J. Paul Getty Museum14 (Los Angeles), National Palace Museum15 (Taipei), Cleveland Museum of Art,16 Art Institute of Chicago,17 Smithsonian Institution18 (Washington), National Gallery of Art19 (Washington), Powerhouse Collection of the Museum of Applied Arts and Sciences20 (New South Wales), and The Met21 (New York). "*([3](zotero://open-pdf/library/items/37EYJ4NA?page=3&annotation=DVEZ5V45))

>[!Annotation|#ffd400]+ 
>*" Digital heritage is no longer a practice of making technical systems work but also a practice of facing new sociotechnical outcomes, as Ross Parry claims, such as recontextualization of GLAM collections by other actors and by machine-to-machine processing of data.43 "*([4](zotero://open-pdf/library/items/37EYJ4NA?page=4&annotation=262MJRUS))

>[!Annotation|#ffd400]+ 
>*" It takes little stretch of the imagination to envision how internet users may use GLAM datasets and generative AI systems like DALL-E to produce images that are abusive, harmful, or extremist while retaining some visual semblance of the underlying works in GLAM collections. "*([4](zotero://open-pdf/library/items/37EYJ4NA?page=4&annotation=PU3NEL2X))

>[!Annotation|#2ea8e5]+ 
>*" we explore potential guardrails that could guide the evolution of GLAM datasets in the age of AI, drawing upon prior scholarship advocating for higher ethical standards of AI dataset development and stewardship "*([4](zotero://open-pdf/library/items/37EYJ4NA?page=4&annotation=ZGRNZ5UY))

>[!Annotation|#ffd400]+ 
>*" To make a dataset is to engage in ethical choices that impact a broad set of stakeholders. GLAM datasets take shape from a combination of contributions from inside and outside the institution. Mass digitization projects at cultural memory institutions, while formally seeking to serve the public interest, are infused with diverse and even conflicting political and economic motives.50 "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=GKQQ9JM2))

>[!Annotation|#ffd400]+ 
>*" AI systems derived from GLAM datasets subsequently inherit and embed new, value-laden norms, assumptions, and design decisions that reflect power dynamics and human labor underlying their production.51 "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=LYIYHPKH))

>[!Annotation|#ffd400]+ 
>*" GLAM datasets reflect a series of design choices and power structures that have built the institution’s physical collection over time, extending this history into the present.52 In turn, the datasets shape an expanse of experiences for internet “prosumers” who not only consume content but produce new engagements by downloading, uploading, sharing, tagging, and remixing.53 "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=N8Z3TB9X))

>[!Annotation|#2ea8e5]+ 
>*" 53 In the age of AI, how GLAMs will develop new policies and practices to deal with these chains of stakeholders and their interactions is a rich question that merits fuller discussion. "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=IH6XF6ZV))

>[!Annotation|#ffd400]+ 
>*" We suggest that GLAMs’ contribution to the development of AI systems through the datasets they develop and make available on the internet will intensify pressures on GLAMs to be transparent about choices and actions in dataset development. This is partly because risk-based governance—which is marked by transparency-centered regulation mechanisms, such as audit, reporting, and risk assessment—has come into favor in regulation of digital society and digital markets.58 "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=2K4MSM88))

>[!Annotation|#ffd400]+ 
>*" Similar to an environment impact assessment that precedes a real estate development project, an impact evaluation framework for GLAMs would enable more informed choices about ethical and social implications, although research and consensus-building are needed to establish an accepted procedure for memory institutions. "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=FETU2I34))

>[!Annotation|#5fb236]+ 
>*" Recommendation 1: Conduct an impact assessment about interaction between dataset decision choices and knowledge paradigms or biases "*([5](zotero://open-pdf/library/items/37EYJ4NA?page=5&annotation=TIJMFB6L))

>[!Annotation|#ffd400]+ 
>*" Collections-as-data approaches have proposed standardization of documentation, such as data packets that bundle transcriptions with contextualizing information to explain decisions made while creating data.61 "*([6](zotero://open-pdf/library/items/37EYJ4NA?page=6&annotation=VG7XYD4P))

>[!Annotation|#ffd400]+ 
>*" documentation serves to hold dataset developers accountable for their decisions, enable dataset users inside and outside GLAMs to make responsible decisions regarding safe and appropriate use, and allow third-party researchers to offer validation or critique as part of scholarly practice "*([6](zotero://open-pdf/library/items/37EYJ4NA?page=6&annotation=C3X36R2S))

>[!Annotation|#5fb236]+ 
>*" Recommendation 2: Produce comprehensive documentation, including decision provenance, of how the dataset is made. Make the documentation available for review outside the institution. "*([6](zotero://open-pdf/library/items/37EYJ4NA?page=6&annotation=62N8B4DH))

>[!Annotation|#ffd400]+ 
>*" Researchers have recognized the gap in guidance for documentation of arts-related dataset development. For example, Artsheets is a research-based and practice-oriented framework that offers a checklist and questionnaire to guide arts-based dataset documentation efforts with specific focus on ethical, social, cultural, legal, and historical considerations.6 "*([6](zotero://open-pdf/library/items/37EYJ4NA?page=6&annotation=3EUVYHA4))

>[!Annotation|#ffd400]+ 
>*" Classification systems serve an important purpose; they lend order to the incredible complexity of the world. These systems are an essential component of turning GLAM collections into machine-readable datasets. Yet, as Geoffrey Bowker and Susan Leigh Star remind us,68 classifications embed politics. When making GLAM datasets, choices of which categories to include and how to sort data are critical design decisions that shape the final dataset by making some aspects of the underlying collection legible and other aspects illegible or lost entirely. Furthermore, classification decisions compound over time, since varying labels can be added at different moments and by different people. "*([7](zotero://open-pdf/library/items/37EYJ4NA?page=7&annotation=7KRSDEUN))

>[!Annotation|#ffd400]+ 
> 
>
>Discussion of construction of met csv, implications of 11 of 54 columns about the creator rather than ole of onject in world

>[!Annotation|#ffd400]+ 
>*" A significant portion—11 columns out of 54— conveyed information for each museum artifact about the biography of the artist.69 At the same time, there were zero columns reserved for other important aspects of an object’s history and cultural meaning, such as its state of preservation.  The proportion 11/54 represents an inbuilt intelligibility that invites users to explore more questions about the artist of each object and fewer about its ritual status, affective presence, physical state over time, and a number of other issues that remain suppressed because of the choice about which classifications are available in the CSV file.70 "*([7](zotero://open-pdf/library/items/37EYJ4NA?page=7&annotation=YZUZXAPF))

>[!Annotation|#ffd400]+ 
>*" Consider how the computational title Figure erases interpretive context. The sculpture’s traditional title evokes the object’s religious derivation (Jain), color (svetambara or white-clad), devotional association (tirthankara or ford- crosser), and attitude (in meditation).71 It is unsurprising to find that other scholarly authors employ slightly different terms for the same object, such as Seated Jain Tirthankara, 72 reflecting different interpretive and expressive priorities.  This example suggests that, whereas humanities methods allow categories like “title” to remain contingent and thickly descriptive, computational methods freeze them into relatively barren units, often a shortened form. A potential epistemic effect of data classification, therefore, is foreclosure of debate about points of interpretation that may be conditional or provisional. "*([7](zotero://open-pdf/library/items/37EYJ4NA?page=7&annotation=NJRA2DS7))

>[!Annotation|#5fb236]+ 
>*" Recommendation 2a: In the impact assessment and public- facing documentation, include information about consultation with domain experts and stakeholder groups to explore how classifications affect user experience and community representation "*([7](zotero://open-pdf/library/items/37EYJ4NA?page=7&annotation=9RQ7UMFC))

>[!Annotation|#5fb236]+ 
>*" Recommendation 2b: In the impact assessment and public- facing documentation, record assumptions and procedures for data cleaning. "*([8](zotero://open-pdf/library/items/37EYJ4NA?page=8&annotation=SGK5XEZC))

>[!Annotation|#ffd400]+ 
>*" One of the core assumptions underlying the crowdsourcing paradigm is that workers are interchangeable. However, scholars have contested this assumption by studying how the perspectives of individual annotators—shaped by social and cultural identities, familiarity with the problem domain, training, and expertise, and more—influence the resulting dataset labels.77 "*([8](zotero://open-pdf/library/items/37EYJ4NA?page=8&annotation=UFSX63NR))

>[!Annotation|#ffd400]+ 
>*" It is critical for GLAM dataset developers to carefully consider whose perspectives, biases, and values are captured within the annotation process and to document annotation processes for external review "*([8](zotero://open-pdf/library/items/37EYJ4NA?page=8&annotation=N8IMN2ER))

>[!Annotation|#ffd400]+ 
>*" It is difficult to perceive how the artifact could possibly be signified reliably by the three tags, Christ—Man—Donkey. Rather, the logic of keyword thinking suppresses many aspects of the pyxis. "*([8](zotero://open-pdf/library/items/37EYJ4NA?page=8&annotation=N28DAS4U))

>[!Annotation|#2ea8e5]+ 
>*" Recommendation 2c: If annotation will rely on crowdsourced labor, document why in the impact assessment and external- facing documentation, and create a record of the annotation process, including sociodemographic information about annotators, in order to situate the resulting dataset. "*([9](zotero://open-pdf/library/items/37EYJ4NA?page=9&annotation=NIRY7YTP))

>[!Annotation|#2ea8e5]+ 
>*" AI and “Big Data” refer not only to the use of tools and processes for developing and analyzing large datasets—they also signify a computational turn in thought.83 The memory cultivated by the logic of databases and computational methods is far from the type of memory that GLAMs have traditionally committed to foster and preserve. "*([10](zotero://open-pdf/library/items/37EYJ4NA?page=10&annotation=TW4QIWHR))

>[!Annotation|#2ea8e5]+ 
>*" The ability to analyze data through powerful statistical programs creates many new affordances and opportunities to explore digital data at scale. Yet this mode of engagement with GLAM collections strips away conditions for meaningful interpretation, such as familiarity with cultures represented by texts, art, and artifacts. This important consideration is often lost in the allure around computation of datasets—similar to Alexander Campolo and Kate Crawford’s concept of “enchanted determinism”86—because of reasons such as terrific speed, efficiency, and rationality. "*([10](zotero://open-pdf/library/items/37EYJ4NA?page=10&annotation=3PTZW79Q))

>[!Annotation|#2ea8e5]+ 
>*" Recommendation 3: Consider future opportunities and risks presented by the kinds of thinking that computational methods promote, and how such futures might advance or degrade the institution’s mission. Foster opportunities and mitigate risks accordingly "*([10](zotero://open-pdf/library/items/37EYJ4NA?page=10&annotation=W7XJDV6G))

>[!Annotation|#ffd400]+ 
>*" To explain this recommendation, we focus on two consequences of computational thinking: context stripping and seeing patterns where none exist. "*([10](zotero://open-pdf/library/items/37EYJ4NA?page=10&annotation=9QLWLU6Z))

>[!Annotation|#ffd400]+ 
>*" As danah boyd and Kate Crawford point out: “Too often, Big Data enables the practice of apophenia: seeing patterns where none actually exist, simply because enormous quantities of data can offer connections that radiate in all directions.”96 "*([11](zotero://open-pdf/library/items/37EYJ4NA?page=11&annotation=H54BEFML))

>[!Annotation|#ffd400]+ 
>*" A case in point from a GLAM dataset is The Met’s Art Explorer.97 The purpose of Art Explorer is to create “a set of pathways through the artworks that would enable user [sic] to traverse the catalog and find interesting associations between the artworks.”98 It is built on Microsoft’s Cognitive Search technology, which performs key tasks with The Met dataset: it generates automated visual tags, performs object recognition with the images of artworks, adds to the artwork’s metadata by using Microsoft’s web search engine, and proposes visually similar artworks. "*([11](zotero://open-pdf/library/items/37EYJ4NA?page=11&annotation=YIK2C4CS))

>[!Annotation|#ffd400]+ 
>*" The museum’s response to the machine’s match between Olive Trees and Demons Fighting exemplifies a key feature of Campolo and Crawford’s notion of enchanted determinism: proponents of an AI system use data abundance to forego the types of explanations that have long been widely expected in our scientific era, causality and theoretical mechanisms.102 Instead, causal explanation and theorization are thrown out in favor of the machine’s capacity to find correlations. "*([12](zotero://open-pdf/library/items/37EYJ4NA?page=12&annotation=ETKC675A))

>[!Annotation|#2ea8e5]+ 
> 
>
>a bit like trusting the gps even when you know the route is wrong

>[!Annotation|#ffd400]+ 
>*" Though any single use of Art Explorer seems harmless, it lays groundwork for an apophenia similar to that found in computational fields wherein messy, real-world sources are forgotten and replaced by orderly, mathematical proxies.  The real-world sociotechnical consequences of this include risks of cultural misrepresentation.103 "*([12](zotero://open-pdf/library/items/37EYJ4NA?page=12&annotation=B9WBDGMH))

>[!Annotation|#ffd400]+ 
>*" Critical researchers argue that datasets are long-term processes rather than static things,108 and that dataset management is perpetual work,109 giving rise to the imperative that organizations create dataset maintenance plans. "*([13](zotero://open-pdf/library/items/37EYJ4NA?page=13&annotation=ZZRZWD47))

>[!Annotation|#2ea8e5]+ 
>*" Recommendation 4: Establish a dataset maintenance plan, including careful assessment of terms and conditions of use informed by the impact assessment that accounts for potential uses of the dataset by others. "*([13](zotero://open-pdf/library/items/37EYJ4NA?page=13&annotation=XW2VFLPH))

>[!Annotation|#2ea8e5]+ 
>*" Recommendation 5: Emphasize the institution’s stewardship of the data by publicly communicating its commitment to cybersecurity. "*([14](zotero://open-pdf/library/items/37EYJ4NA?page=14&annotation=USXV2T63))

>[!Annotation|#2ea8e5]+ 
>*" Recommendation 5a: GLAMs’ datasets ought to be evaluated and secured as part of the organization’s adherence to an internationally recognized security framework. A generally accepted gold standard is the U.S. National Institute of Standards and Technology (NIST) Cybersecurity Framework.117 The NIST framework provides risk assessment guidelines and is intended to scale with the organization’s resources. "*([14](zotero://open-pdf/library/items/37EYJ4NA?page=14&annotation=FEIE7CKC))

>[!Annotation|#2ea8e5]+ 
>*" Recommendation 5b: Get help from an organization in civil society or academia that helps nonprofits build capacity to defend against digital threats. Examples include CyberPeace Builders,118 the Consortium of Cybersecurity Clinics,119 and Microsoft Security Program for Nonprofits.120 "*([14](zotero://open-pdf/library/items/37EYJ4NA?page=14&annotation=GE4J2QF8))

>[!Annotation|#2ea8e5]+ 
>*" In particular, we stress that our recommendations 1 and 2 will require alignment among GLAMs about what good impact assessment and dataset documentation look like. Toward that objective, we provided some ideas to explore: • In the impact assessment and public-facing documentation, include information about consultation with domain experts and stakeholder groups to explore how classifications affect user experience and community representation.  • In the impact assessment and public-facing documentation, record assumptions and procedures for data cleaning.  • If annotation will rely on crowdsourced labor, document why in the impact assessment and public-facing documentation, and create a record of the annotation process, including sociodemographic information about annotators, in order to situate the resulting dataset. "*([14](zotero://open-pdf/library/items/37EYJ4NA?page=14&annotation=T94TFZ42))

