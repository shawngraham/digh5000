---
Title: "Ex figlinis: the complex dynamics of the Roman brick industry in the Tiber Valley during the 1st to 3rd centuries AD"
Authors: Shawn Graham

Date: 2002-01-01
citekey: grahamExFiglinisComplex2002
tags: 
---

> [!Cite]
> 

>[!Synth]
>**Contribution**:: 
>
>**Related**:: 
>

>[!md]
> **FirstAuthor**:: Graham, Shawn  
~    
> **Title**:: Ex figlinis: the complex dynamics of the Roman brick industry in the Tiber Valley during the 1st to 3rd centuries AD  
> **Year**:: 2002   
> **Citekey**:: grahamExFiglinisComplex2002  
> **itemType**:: thesis    

> [!LINK] 
>.

> [!Abstract]
>.
> 
> ### Note
>.


