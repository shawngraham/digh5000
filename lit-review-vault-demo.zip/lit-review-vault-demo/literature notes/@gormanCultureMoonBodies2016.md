---
Title: "Culture on the Moon: Bodies in Time and Space"
Authors: Alice Gorman
Publication: "Archaeologies"
Date: 2016-04-01
citekey: gormanCultureMoonBodies2016
tags: #Apollo-11, #Culture, #Soviet-space-program, #Space-archaeology, #Toss-zone
---

> [!Cite]
> Gorman, A. 2016 Culture on the Moon: Bodies in Time and Space. _Archaeologies_ 12(1): 110–128. DOI: [https://doi.org/10.1007/s11759-015-9286-7](https://doi.org/10.1007/s11759-015-9286-7).

>[!Synth]
>**Contribution**::The idea of space being gendered and coded masculine/feminine in various ways 
>
>**Related**:: 
>

>[!md]
> **FirstAuthor**:: Gorman, Alice  
~    
> **Title**:: Culture on the Moon: Bodies in Time and Space  
> **Year**:: 2016   
> **Citekey**:: gormanCultureMoonBodies2016  
> **itemType**:: journalArticle  
> **Journal**:: *Archaeologies*  
> **Volume**:: 12  
> **Issue**:: 1   
> **Pages**:: 110-128  
> **DOI**:: 10.1007/s11759-015-9286-7    

> [!LINK] 
>
>  [gorman2016.pdf](file:///Users/shawngraham/Zotero/storage/2556B5S7/gorman2016.pdf).

> [!Abstract]
>
> This paper investigates whether the term ‘culture’ can be applied to the six Apollo lunar landing sites, and how the remains at these sites can be understood as the actions of bodies at a particular moment in space and time.
>.
> # Notes
>
>Thought occurs: the space archaeology needs to be theorizede space archaeology needs to be theorized.


>[!Annotation|#5fb236]+ 
>*" On the one hand, humans have colonised both sea and air using technology, so space exploration could be seen as a natural extension of this trajectory. On the other, it could be argued that the interplanetary environment is so radically different that terrestrial analogies do not apply. "*([3](zotero://open-pdf/library/items/2556B5S7?page=3&annotation=CXG75DXX))

>[!Annotation|#5fb236]+ 
>*" Orbital catalogues based on tracked data are main- tained by several space agencies, and some versions of these data are pub- licly available, e.g. in the Heavens Above (2013) and CelesTrak databases (2013); however, these carry little information about the objects other than their year of launch, name or designation, and orbit "*([5](zotero://open-pdf/library/items/2556B5S7?page=5&annotation=4LNTFG53)) 
>
>likely not graph db

>[!Annotation|#5fb236]+ 
>*" Apollo ‘culture’ on the Moon is unique, in that it is precisely bounded in both time and space—beginning in 1969 with Apollo 11, and ending in 1972 with Apollo 17 (see Binford 1964:431; Trigger 2006:233).  Apollo culture is Cold War and nationalist (Gorman and O’Leary 2007; Launius 2007), if not actually ‘ethnic’. (An investigation of how the Apollo culture represents humanity, opposed to USA culture, could be illuminat- ing). It could even be called ‘primitive’ compared to today’s space technol- ogy. On Earth, it had deeper antecedents, for example in the WW II V2 rocket program, and it evolved into the Apollo Applications program, which led to the first US space station Skylab (Hitt et al. 2008) "*([8](zotero://open-pdf/library/items/2556B5S7?page=8&annotation=N8UGA4ZH))

>[!Annotation|#5fb236]+ 
>*" The thousands of images from the Apollo missions (artefacts in their own right), combined with detailed descriptions in the Lunar Surface Journal, could enable areas associated with the performance of different activities to be mapped and compared "*([11](zotero://open-pdf/library/items/2556B5S7?page=11&annotation=2GYCWQE2)) 
>
>Our system could be used!

>[!Annotation|#5fb236]+ 
>*" It’s also noteworthy, although rarely remarked upon, that the lunar sites are gendered. "*([12](zotero://open-pdf/library/items/2556B5S7?page=12&annotation=5D7I5PX2)) 
>
>Did vie even think about gender in our paper

>[!Annotation|#5fb236]+ 
>*" The bodies of both were the expres- sions of ideology. The US astronauts were meant to embody ‘‘the age-old American icons of control and mythologies of individuality and autonomy, from cowboys to sea captains’’ (Mindell 2008:5, see also McCurdy 1997).  For the story to work, Mindell argues, the astronauts had to be in control, to have mastery (2008:12). Some astronauts equated loss of the pilot role as a threat to their masculinity (Mindell 2008:14). "*([13](zotero://open-pdf/library/items/2556B5S7?page=13&annotation=IKRGEYP2)) 
>
>Issap

>[!Annotation|#5fb236]+ 
>*" Digging deeper into the conceptual foundations of Capelotti’s proposed Apollo culture, the examples of the toss zone (O’Leary et al. 2002) and the autonomous astronaut bodies support the idea that the space environment creates a cohesive culture defined by a repeated suite of artefacts and embod- ied behaviours. "*([14](zotero://open-pdf/library/items/2556B5S7?page=14&annotation=PXTYYC65))

