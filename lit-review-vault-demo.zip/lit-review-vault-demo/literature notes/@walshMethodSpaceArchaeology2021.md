---
Title: "A method for space archaeology research: the International Space Station Archaeological Project"
Authors: Justin St P. Walsh, Alice C. Gorman
Publication: "Antiquity"
Date: 2021-10-01
citekey: walshMethodSpaceArchaeology2021
tags: 
---

> [!Cite]
> Walsh, JSP and Gorman, AC. 2021 A method for space archaeology research: the International Space Station Archaeological Project. _Antiquity_ 95(383): 1331–1343. DOI: [https://doi.org/10.15184/aqy.2021.114](https://doi.org/10.15184/aqy.2021.114).

>[!Synth]
>**Contribution**::sets some questions for space archae. mentions machine vision as key tech. sg how can that be gender coded? 
>
>**Related**::[[@gormanGravityArchaeology2009]] 
>

>[!md]
> **FirstAuthor**:: Walsh, Justin St P.  
> **Author**:: Gorman, Alice C.  
~    
> **Title**:: A method for space archaeology research: the International Space Station Archaeological Project  
> **Year**:: 2021   
> **Citekey**:: walshMethodSpaceArchaeology2021  
> **itemType**:: journalArticle  
> **Journal**:: *Antiquity*  
> **Volume**:: 95  
> **Issue**:: 383   
> **Pages**:: 1331-1343  
> **DOI**:: 10.15184/aqy.2021.114    

> [!LINK] 
>.

> [!Abstract]
>
> How does a ‘space culture’ emerge and evolve, and how can archaeologists study such a phenomenon? The International Space Station Archaeological Project seeks to analyse the social and cultural context of an assemblage relating to the human presence in space. Drawing on concepts from contemporary archaeology, the project pursues a unique perspective beyond sociological or ethnographical approaches. Semiotic analysis of material culture and proxemic analysis of embodied space can be achieved using NASA's archives of documentation, images, video and audio media. Here, the authors set out a method for the study of this evidence. Understanding how individuals and groups use material culture in space stations, from discrete objects to contextual relationships, promises to reveal intersections of identity, nationality and community.
>.
> 
> ### Note
>.


