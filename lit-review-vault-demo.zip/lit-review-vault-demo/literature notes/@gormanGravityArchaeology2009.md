---
Title: "The Gravity of Archaeology"
Authors: Alice Gorman
Publication: "Archaeologies"
Date: 2009-08-01
citekey: gormanGravityArchaeology2009
tags: 
---

> [!Cite]
> Gorman, A. 2009 The Gravity of Archaeology. _Archaeologies_ 5(2): 344–359. DOI: [https://doi.org/10.1007/s11759-009-9104-1](https://doi.org/10.1007/s11759-009-9104-1).

>[!Synth]
>**Contribution**::the idea that a 'site' in space is a swarm, is a distributed dynamic system 
>
>**Related**::  [[@gormanPostGeocentricGravitographyHuman2023]] 
>

>[!md]
> **FirstAuthor**:: Gorman, Alice  
~    
> **Title**:: The Gravity of Archaeology  
> **Year**:: 2009   
> **Citekey**:: gormanGravityArchaeology2009  
> **itemType**:: journalArticle  
> **Journal**:: *Archaeologies*  
> **Volume**:: 5  
> **Issue**:: 2   
> **Pages**:: 344-359  
> **DOI**:: 10.1007/s11759-009-9104-1    

> [!LINK] 
>
>  [Gorman - 2009 - The Gravity of Archaeology.pdf](file:///Users/shawngraham/Zotero/storage/GXK3QLNG/Gorman%20-%202009%20-%20The%20Gravity%20of%20Archaeology.pdf).

> [!Abstract]
>
> One of the defining features of the material culture of space exploration is the fact that much of it is ‘‘out there’’: in orbit around celestial bodies and on planetary surfaces. In outer space, we have to rethink the meaning of place. Cartesian coordinates must be replaced with equations of motion to describe the ceaseless movement of heavenly objects in relation to centres of gravity. Archaeological sites in space are not solid condensations of artefacts, hundreds or thousands of years compressed into layers perhaps only centimetres deep. The materials of an archaeological deposit become rather a cloud or swarm. But for both Earth and space, gravity is the structuring force. In this paper I want to reconceptualise archaeological sites according to their position in the gravity well, using dynamical systems and Riemann surfaces. I then consider the Mir space station as an example of a site existing simultaneously on Earth and in orbit, as a preliminary excursion towards a frame of reference that can be used to effectively conduct an archaeology in outer space.
>.
> # Notes
>
># Annotations  
(2024-02-14, 3:51:13 p.m.)

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=1&annotation=VA7TIA7U) “Cartesian coordinates must be replaced with equations of motion to describe the ceaseless movement of heavenly objects in relation to centres of gravity” ([Gorman, 2009, p. 1](zotero://select/library/items/32VQE6DY))

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=1&annotation=UEQR65MH) “The materials of an archaeological deposit become rather a cloud or swarm.” ([Gorman, 2009, p. 1](zotero://select/library/items/32VQE6DY))

([Gorman, 2009, p. 1](zotero://select/library/items/32VQE6DY)) Gravity is implied in structureof database

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=1&annotation=YE7XNUTJ) “But for both Earth and space, gravity is the structuring force.” ([Gorman, 2009, p. 1](zotero://select/library/items/32VQE6DY))

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=F48ZPHDX) “Archaeology on Earth is conducted within a framework of Ptolemaic geocentrism and Euclidean geometry (Gorman 2009:334)” ([Gorman, 2009, p. 3](zotero://select/library/items/32VQE6DY))

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=FNNFBQ6U) “the objects of our enquiry are, to all intents and purposes, immobile: they stay still so that we can record the horizontal (space) and vertical (time) relationships between them, a critical part of archaeological investigation.” ([Gorman, 2009, p. 3](zotero://select/library/items/32VQE6DY))

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=FWGW5EB2) “Unlike terrestrial objects and structures, artefacts in space do not fall and become chronologically layered as the forces of wind, water, chemistry and human actions accumulate deposit around them. They are in perpetual motion relative to our vantage point, and relative to each other.” ([Gorman, 2009, p. 3](zotero://select/library/items/32VQE6DY))

([Gorman, 2009, p. 3](zotero://select/library/items/32VQE6DY)) Important

([Gorman, 2009, p. 3](zotero://select/library/items/32VQE6DY)) Does . considerproblem of the ob

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=BRIEIX7F) “If human material culture in Earth orbit is to be considered as an archaeological record, and this is how I want to con- sider it, then how can we describe spatial and chronological relationships? How can we apply basic archaeological principles to a microgravity environ- ment?” ([Gorman, 2009, p. 3](zotero://select/library/items/32VQE6DY)) ^4c89f2

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=9&annotation=R3R9KBJF) “So now let us take our manifold, curved by matter to create gravity, and put objects like satellites and adzes into it to see how they evolve over time. This is where dynamical systems become useful (Gorman 2009). In brief, a dynamical system is a state or phase space (which can be either Euclidean or non-Euclidean) consisting of points, in which evolution through time is governed by rules such as planetary or orbital equations (Katok and Hasselblatt 1995; Palis and de Melo 1982). Dynamical systems have also been used to describe the change over time of geomorphic states, for example by Thornes (1983). The advantages of a dynamical system approach are that it captures the effects of gravity and entropy over time for any state space, whether terrestrial, celestial or maritime, and can be applied over a manifold.” ([Gorman, 2009, p. 9](zotero://select/library/items/32VQE6DY))

([Gorman, 2009, p. 9](zotero://select/library/items/32VQE6DY)) I'm sure that I could connect this to networks somehow'

[Go to annotation](zotero://open-pdf/library/items/GXK3QLNG?page=12&annotation=NLQSX2GX) “The geodesic manifold, despite its complex mathematics, gives us a kind of map of space on which to plot the movements of artefacts, in which some points stay still over time and others swirl in unceasing motion. To understand a glo- bal industry premised on overcoming terrestrial gravity, it scarcely seems strange that we must look to gravity to explain both where and what it is.” ([Gorman, 2009, p. 12](zotero://select/library/items/32VQE6DY)).


>[!Annotation|#2ea8e5]+ 
>

>[!Annotation|#2ea8e5]+ 
>

>[!Annotation|#5fb236]+ 
>*" Cartesian coordinates must be replaced with equations of motion to describe the ceaseless movement of heavenly objects in relation to centres of gravity "*([1](zotero://open-pdf/library/items/GXK3QLNG?page=1&annotation=VA7TIA7U))

>[!Annotation|#5fb236]+ 
>*" The materials of an archaeological deposit become rather a cloud or swarm. "*([1](zotero://open-pdf/library/items/GXK3QLNG?page=1&annotation=UEQR65MH))

>[!Annotation|#2ea8e5]+ 
> 
>
>Gravity is implied in structureof database

>[!Annotation|#5fb236]+ 
>*" But for both Earth and space, gravity is the structuring force. "*([1](zotero://open-pdf/library/items/GXK3QLNG?page=1&annotation=YE7XNUTJ))

>[!Annotation|#5fb236]+ 
>*" Archaeology on Earth is conducted within a framework of Ptolemaic geocentrism and Euclidean geometry (Gorman 2009:334) "*([3](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=F48ZPHDX))

>[!Annotation|#5fb236]+ 
>*" the objects of our enquiry are, to all intents and purposes, immobile: they stay still so that we can record the horizontal (space) and vertical (time) relationships between them, a critical part of archaeological investigation. "*([3](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=FNNFBQ6U))

>[!Annotation|#5fb236]+ 
>*" Unlike terrestrial objects and structures, artefacts in space do not fall and become chronologically layered as the forces of wind, water, chemistry and human actions accumulate deposit around them. They are in perpetual motion relative to our vantage point, and relative to each other. "*([3](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=FWGW5EB2))

>[!Annotation|#2ea8e5]+ 
> 
>
>Important

>[!Annotation|#2ea8e5]+ 
> 
>
>Does . considerproblem of the ob

>[!Annotation|#ffd400]+ 
>*" If human material culture in Earth orbit is to be considered as an archaeological record, and this is how I want to con- sider it, then how can we describe spatial and chronological relationships? How can we apply basic archaeological principles to a microgravity environ- ment? "*([3](zotero://open-pdf/library/items/GXK3QLNG?page=3&annotation=BRIEIX7F))

>[!Annotation|#aaaaaa]+ 
>*" So now let us take our manifold, curved by matter to create gravity, and put objects like satellites and adzes into it to see how they evolve over time. This is where dynamical systems become useful (Gorman 2009). In brief, a dynamical system is a state or phase space (which can be either Euclidean or non-Euclidean) consisting of points, in which evolution through time is governed by rules such as planetary or orbital equations (Katok and Hasselblatt 1995; Palis and de Melo 1982). Dynamical systems have also been used to describe the change over time of geomorphic states, for example by Thornes (1983). The advantages of a dynamical system approach are that it captures the effects of gravity and entropy over time for any state space, whether terrestrial, celestial or maritime, and can be applied over a manifold. "*([9](zotero://open-pdf/library/items/GXK3QLNG?page=9&annotation=R3R9KBJF))

>[!Annotation|#2ea8e5]+ 
> 
>
>I'm sure that I could connect this to networks somehow'

>[!Annotation|#5fb236]+ 
>*" The geodesic manifold, despite its complex mathematics, gives us a kind of map of space on which to plot the movements of artefacts, in which some points stay still over time and others swirl in unceasing motion. To understand a glo- bal industry premised on overcoming terrestrial gravity, it scarcely seems strange that we must look to gravity to explain both where and what it is. "*([12](zotero://open-pdf/library/items/GXK3QLNG?page=12&annotation=NLQSX2GX))

